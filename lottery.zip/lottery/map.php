<?php
$url = $_POST['url'] ?? null;
$liczba = 1;
$nazwa = array();
if($url !== null){
    $file = fopen($url, "r");
    $myfile = fopen("lista.lottery", "w");
    while(!feof($file)) {
        $str = fgets($file);
        // Podziel linię na elementy po tabulacji
        $elements = explode("\t", $str);
        // Sprawdź, czy istnieje drugi element (indeks 1) i czy jest liczbą
        // Wyświetl znalezioną liczbę
        for($i = 0; $i < (int)$elements[1]; $i++){
            $temp = $liczba. " ". $elements[0]. "\n";
            echo $temp;
            fwrite($myfile, $temp);
            $liczba = $liczba + 1;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mapowanie chyba</title>
</head>
<body>
    <form action="map.php" method="post">

        <input type="text" name="url" id="url">
        <button type="submit">Dodaj z lokalizacji</button>

    </form>
</body>
</html>