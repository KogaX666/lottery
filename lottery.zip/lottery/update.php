<?php
require_once('db.php');

$stmt = $db->prepare('SELECT id, imie, nazwisko, klasa, ilosc FROM talony WHERE id=:id');
$stmt->execute([
    'id' => $_POST['id'],
]);
$produkty = $stmt->fetch();


$imie = $_POST["imie"] ?? null;
$nazwisko = $_POST["nazwisko"] ?? null;
$klasa = $_POST["klasa"] ?? null;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
foreach($produkty as $p){
    echo $p['imie'];
}
?>
    <form action="update.php" method="post">
        <input type="text" name="imie" id="imie" placeholder='<?= "{$produkty['imie']}" ?>'>
        <input type="text" name="nazwisko" id="nazwisko" placeholder='<?= "{$produkty['nazwisko']}" ?>'>
        <input type="text" name="klasa" id="klasa" placeholder='<?= "{$produkty['klasa']}" ?>'>
        <button type="submit">Aktualizuj</button>
    </form>
</body>
</html>