<?php
require_once('db.php');

$stmt = $db->prepare('SELECT imie, nazwisko, klasa, ilosc FROM talony ORDER BY nazwisko');
$stmt->execute();
$produkty = $stmt->fetchAll();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<table>
<thead>

    <tr>
        <th>Imie</th>
        <th>Nazwisko</th>
        <th>Klasa</th>
        <th>Ilość</th>
    </tr>

</thead>
<?php
        foreach($produkty as $p){
        ?>

                <tr> <?= "<td>{$p['imie']}</td> <td>{$p['nazwisko']}</td> <td>{$p['klasa']}</td> <td>{$p['ilosc']}</td>" ?></tr>

        <?php
        }
            
        ?>
</table>
</body>
</html>